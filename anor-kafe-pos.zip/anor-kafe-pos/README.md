# Anor Kafe: menyu, QR orqali buyurtma, xodimlar paneli

Bu loyiha o'z serveri bilan ishlaydi. Natija:

- **Ochiq sayt** (`/`): menyu Google'da chiqadi. Mijoz stoldagi QR-kodni skanerlasa, shu sahifada stol raqami o'zi tanlanadi va buyurtma berish tugmalari ochiladi.
- **Xodimlar paneli** (`/admin`): parol bilan kiriladi. Oshxona va bar buyurtmalari alohida ko'rinadi, "Boshlash", "Tayyor", "Berildi" tugmalari bor, yangi buyurtmada ovoz chiqadi, chek chop etish tugmasi bor.
- **Stol QR-kodlari** (`/admin/qr`): panelga kirgandan keyin ochiladi, har stol uchun alohida kod chiqadi va chop etiladi.

> Muhim: bu kod yozilgan, sintaksisi tekshirilgan, lekin serverni ishga tushirib sinab ko'rilmagan.
> Birinchi ishga tushirishda xato chiqsa, xato matnini yuboring, to'g'rilab beramiz.

## 1. Kompyuteringizda sinab ko'rish

Kompyuterga Node.js (18 yoki yangiroq) o'rnating: https://nodejs.org

```
npm install
ADMIN_PASSWORD=sizning-parolingiz npm start
```

Windows (PowerShell) uchun:

```
npm install
$env:ADMIN_PASSWORD="sizning-parolingiz"; npm start
```

Brauzerda oching: http://localhost:3000 (sayt), http://localhost:3000/admin (panel).
Parol kamida 6 belgi bo'lishi kerak, aks holda server ishga tushmaydi.

## 2. Internetga chiqarish (Google'da chiqishi uchun)

Server doimiy ishlab turishi kerak, shuning uchun oddiy fayl hosting (Netlify, GitHub Pages) bu loyiha uchun yaramaydi. Node.js serverni qabul qiladigan xizmat kerak, masalan Render (render.com), Railway yoki o'zingizning VPS.

Render misolida:

1. Loyihani GitHub'ga yuklang (`node_modules` va `data` papkalari yuklanmaydi, `.gitignore` buni hal qiladi).
2. Render'da "New", keyin "Web Service" ni tanlab, shu repozitoriyani ulang.
3. Build command: `npm install`. Start command: `npm start`.
4. "Environment" bo'limiga uchta o'zgaruvchi qo'shing:
   - `ADMIN_PASSWORD`: xodimlar paroli
   - `SECRET`: uzun tasodifiy matn (kamida 24 belgi). Muhim: usiz server qayta ishga tushganda QR-kodlar yaroqsiz bo'lib qoladi.
   - `BASE_URL`: saytingizning to'liq manzili, masalan `https://anorkafe.uz`
5. Sayt ochilgach, `/admin` ga kirib, "Stol QR-kodlari" orqali kodlarni chop eting va stollarga yopishtiring.

Eslatma: bepul hostinglarda server uxlab qolishi va qayta ishga tushganda `data` papkasi tozalanishi mumkin. Bunda faol buyurtmalar yo'qoladi. Doimiy disk (persistent disk) ulasangiz, `DATA_DIR` o'zgaruvchisiga shu diskning yo'lini bering.

## 3. Google'da chiqishi

1. Saytingiz manzilini https://search.google.com/search-console ga qo'shing.
2. "URL tekshirish" orqali bosh sahifani indekslashni so'rang. Sayt `sitemap.xml` va `robots.txt` ni o'zi beradi.
3. Google bir necha kundan bir necha haftagacha vaqt oladi.

## 4. Menyuni o'zgartirish

`menu.json` faylini oching: taomlar, narxlar va stollar ro'yxati shu yerda. O'zgartirgandan keyin serverni qayta ishga tushiring. Har bo'limning `dest` maydoni buyurtma qayerga tushishini belgilaydi: `oshxona` yoki `bar`.

## 5. Qanday himoyalangan

- Buyurtma berish uchun stol QR-kodidagi yashirin kalit kerak. Kalitsiz, faqat saytni ochgan odam buyurtma bera olmaydi.
- Narxlar serverda hisoblanadi, mijoz yuborgan narxga ishonilmaydi.
- Bir stoldan 10 daqiqada 6 tadan ko'p buyurtma qabul qilinmaydi.
- Xodimlar paneliga parol bilan kiriladi, 12 soatdan keyin qayta so'raydi, noto'g'ri parol urinishlari cheklangan.

## 6. Chek chop etish

Xodimlar panelidagi har buyurtmada "Chekni chop etish" tugmasi bor. Termoprinter shu kompyuterga oddiy printer sifatida ulangan bo'lsa, chek 72 mm kenglikda chiqadi. Printerni avtomatik ulash (buyurtma tushishi bilan o'zi chiqishi) bu versiyada yo'q.
